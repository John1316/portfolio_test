import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sayhello',
  templateUrl: './sayhello.component.html',
  styleUrls: ['./sayhello.component.scss']
})
export class SayhelloComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
