import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-to-navbar',
  templateUrl: './to-navbar.component.html',
  styleUrls: ['./to-navbar.component.scss']
})
export class ToNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
